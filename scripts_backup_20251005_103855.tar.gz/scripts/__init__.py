"""Scripts package for FootballPrediction project."""
